Install-OpenCV
==============

shell scripts to install different version of OpenCV in different distributions of Linux